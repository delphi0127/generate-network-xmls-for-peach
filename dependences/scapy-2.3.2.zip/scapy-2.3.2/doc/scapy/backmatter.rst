
*********
Credits
*********

- Philippe Biondi is Scapy's author. He has also written most of the documentation.
- Fred Raynal wrote the chapter on building and dissecting packets.
- Sebastien Martini added some details in "Handling default values: automatic computation".
- Peter Kacherginsky contributed several tutorial sections, one-liners and recipes.
- Dirk Loss integrated and restructured the existing docs to make this book. 
  He has also written the installation instructions for Windows.

   
